<?php
    $myscli = false;
    function connectDB () {
        global $mysqli;
        $mysqli = new mysqli("mysql.hostinger.com.ua", "u638319463_hans", "12093487", "u638319463_cl");
        $mysqli->query("SET NAMES 'utf-8'");
    }

    function closeDB () {
        global $mysqli;
        $mysqli->close ();
    }

    function getItemsNum ($table) {
        global $mysqli;
        connectDB();
        $maxid = $mysqli->query("SELECT id FROM $table ORDER BY id DESC LIMIT 1")->fetch_assoc ();
        closeDB();
        return $maxid["id"];
    }

    function getList ($table, $itemsNum, $page) {
        global $mysqli;
        connectDB();
        $max = $itemsNum - (($page - 1) * 5);
        $min = $itemsNum - (($page - 1) * 5) - 5;
        $result = $mysqli->query("SELECT * FROM $table WHERE id <= $max AND id > $min ORDER BY id DESC");
        closeDB();
        return resultToArray ($result);
    }

    function resultToArray ($result) {
        $array = array ();
        while ($row = $result->fetch_assoc())
            $array[] = $row;
        return $array;
    }
?>