<footer>
    <div id="copyright">
        <p>All rights reserved &copy; <?=date ('Y')?> </p>
    </div>
</footer>