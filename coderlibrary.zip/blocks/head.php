<meta http-equiv="Content-type" content="text/html" charset="utf-8" />
<meta name="description" content="Учебный проект начинающего программиста Колоколова Алексея." />
<meta name="keywords" content="Колоколов+Алексей, Библионтека+кодера, HTML, PHP, Java" />
<title><?=$title?></title>
<link href="/css/style.css" rel="stylesheet" type="text/css" />