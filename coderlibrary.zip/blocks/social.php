<article>
    <h2>Найдите меня в сети</h2>
    <div id="social">
        <a href="http://vk.com/dj_hans" target="_blank" >
            <img src="/img/vk.png" title="Я ВКонтакте" />
        </a>
        <a href="https://www.facebook.com/aleksey.kolokolov" target="_blank">
            <img src="/img/facebook.png" title="Я на Facebook"/>
        </a>
        <a href="https://github.com/AlexKolokolov" target="_blank">
            <img src="/img/github.png" title="Я на GitHub"/>
        </a>
    </div>
</article>